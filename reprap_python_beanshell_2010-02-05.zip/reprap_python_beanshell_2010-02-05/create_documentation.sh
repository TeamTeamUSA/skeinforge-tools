#!/bin/bash

# Edit to point to correct skeinforge_tools directory
# cd /Applications/MakerBot/SkeinFox.app/Contents/Resources/skeinforge-0005_tb/skeinforge_tools

rm -rf html
mkdir html
pydoc -w ./
find ./ -type f -name "*.html" -exec mv -f {} html \;
find ./ -type f -name "*.pyc" -exec rm -f {} \;
cd html

for i in $( ls * ); 
do
	src=$i
#	tgt=`echo $src | perl -pe 's/^([a-zA-Z0-9_]+[\.]?[a-zA-Z0-9_]+[\.]?[a-zA-Z0-9_]+)\.html/skeinforge_tools.$1.html/'`
	tgt=`echo $src | perl -pe 's/^([a-zA-Z0-9_]+[\.]?[a-zA-Z0-9_]+[\.]?[a-zA-Z0-9_]+)\.html/$1.html/'`
	mv $src $tgt
done